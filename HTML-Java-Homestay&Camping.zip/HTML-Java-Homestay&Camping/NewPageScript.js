// Sample data (replace with data from backend)
const homestays = [
        { name: "Homestay A", location: "dalat", price: 500000, amenities: ["wifi", "pool"], image: "Images/images (1).jpg" }, // Thay thế "homestayA.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping B", location: "sapa", price: 300000, amenities: ["bbq"], image: "Images/images (2).jpg" }, // Thay thế "images/campingB.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay C", location: "dalat", price: 600000, amenities: ["wifi", "pool"], image: "Images/images (3).jpg" }, // Thay thế "images/homestayC.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping D", location: "sapa", price: 400000, amenities: ["bbq"], image: "Images/images (4).jpg" }, // Thay thế "images/campingD.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay E", location: "dalat", price: 550000, amenities: ["wifi"], image: "Images/images (5).jpg" }, // Thay thế "images/homestayE.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping F", location: "sapa", price: 350000, amenities: ["pool"], image: "Images/images (6).jpg" }, // Thay thế "images/campingF.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay G", location: "dalat", price: 700000, amenities: ["wifi", "bbq"], image: "Images/images (7).jpg" }, // Thay thế "images/homestayG.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping H", location: "sapa", price: 450000, amenities: ["wifi"], image: "Images/tải xuống (9).jpg" }, // Thay thế "images/campingH.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay I", location: "dalat", price: 800000, amenities: ["pool"], image: "Images/tải xuống (10).jpg" }, // Thay thế "images/homestayI.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping J", location: "sapa", price: 500000, amenities: ["bbq"], image: "Images/tải xuống (8).jpg" }, // Thay thế "images/campingJ.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay K", location: "dalat", price: 650000, amenities: ["wifi", "pool"], image: "Images/tải xuống (11).jpg" }, // Thay thế "images/homestayK.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping L", location: "sapa", price: 370000, amenities: ["wifi"], image: "Images/tải xuống (12).jpg" }, // Thay thế "images/campingL.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay M", location: "dalat", price: 720000, amenities: ["bbq"], image: "Images/tải xuống (13).jpg" }, // Thay thế "images/homestayM.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping N", location: "sapa", price: 480000, amenities: ["pool"], image: "Images/tải xuống (14).jpg" }, // Thay thế "images/campingN.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay O", location: "dalat", price: 590000, amenities: ["wifi", "pool"], image: "Images/tải xuống (15).jpg" }, // Thay thế "images/homestayO.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping P", location: "sapa", price: 390000, amenities: ["bbq"], image: "Images/tải xuống (16).jpg" }, // Thay thế "images/campingP.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay Q", location: "dalat", price: 750000, amenities: ["wifi"], image: "Images/tải xuống (17).jpg" }, // Thay thế "images/homestayQ.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping R", location: "sapa", price: 420000, amenities: ["pool"], image: "Images/tải xuống (18).jpg" }, // Thay thế "images/campingR.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay S", location: "dalat", price: 680000, amenities: ["wifi", "bbq"], image: "Images/tải xuống (19).jpg" }, // Thay thế "images/homestayS.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping T", location: "sapa", price: 460000, amenities: ["wifi"], image: "Images/tải xuống (20).jpg" }, // Thay thế "images/campingT.jpg" bằng đường dẫn ảnh thực tế
        { name: "Homestay U", location: "dalat", price: 710000, amenities: ["pool"], image: "Images/tải xuống (21).jpg" }, // Thay thế "images/homestayU.jpg" bằng đường dẫn ảnh thực tế
        { name: "Camping V", location: "sapa", price: 530000, amenities: ["bbq"], image: "Images/tải xuống.jpg" }, // Thay thế "images/campingV.jpg" bằng đường dẫn ảnh thực tế
    ];


function displayHomestays(filteredHomestays = homestays) {
    const list = document.getElementById("homestayList");
    list.innerHTML = "";

    filteredHomestays.forEach(homestay => {
        const item = document.createElement("div");
        item.className = "homestay-item";
        item.innerHTML = `
            <img src="${homestay.image}" alt="${homestay.name}" style="width:100%; height:auto;">
            <h3>${homestay.name}</h3>
            <p>Vị trí: ${homestay.location}</p>
            <p>Giá: ${homestay.price} VND</p>
            <p>Tiện ích: ${homestay.amenities.join(", ")}</p>
        `;
        list.appendChild(item);
    });
}

function applyFilters() {
    const location = document.getElementById("location").value;
    const price = parseInt(document.getElementById("price").value);
    const amenities = Array.from(document.querySelectorAll('input[name="amenity"]:checked'))
        .map(cb => cb.value);

    const filtered = homestays.filter(homestay => {
        if (location && homestay.location !== location) return false;
        if (homestay.price > price) return false;
        if (amenities.length > 0 && !amenities.every(amenity => homestay.amenities.includes(amenity))) return false;
        return true;
    });

    displayHomestays(filtered);
}

document.getElementById("applyFilters").addEventListener("click", applyFilters);

// Display the value of the range slider
const priceInput = document.getElementById("price");
const priceValue = document.getElementById("priceValue");
priceValue.textContent = priceInput.value + " VND";
priceInput.addEventListener("input", () => {
    priceValue.textContent = priceInput.value + " VND";
});

displayHomestays(); // Display all homestays when the page loads
